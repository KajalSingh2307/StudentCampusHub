<!DOCTYPE html>
<html>
<head>
<title>Notices</title>
<link rel="stylesheet" href="css/style.css">
</head>

<body>

<h2>Campus Notices</h2>

<ul>
    <li>Semester Exams start from 15 June</li>
    <li>Hackathon Registration Open</li>
    <li>Library Timings Updated</li>
</ul>

</body>
</html>