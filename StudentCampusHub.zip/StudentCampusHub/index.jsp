<!DOCTYPE html>
<html>
<head>
<title>Student Campus Hub</title>
<link rel="stylesheet" href="css/style.css">
</head>

<body>

<h1>Student Campus Hub</h1>

<a href="register.jsp">Register</a>
<br><br>

<a href="login.jsp">Login</a>

</body>
</html>