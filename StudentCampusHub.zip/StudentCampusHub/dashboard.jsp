<%@ page session="true" %>

<!DOCTYPE html>
<html>
<head>
<title>Dashboard</title>
<link rel="stylesheet" href="css/style.css">
</head>

<body>

<h1>
Welcome,
<%= session.getAttribute("user") %>
</h1>

<br>

<a href="notices.jsp">Campus Notices</a>

<br><br>

<a href="events.jsp">Campus Events</a>

<br><br>

<a href="LogoutServlet">Logout</a>

</body>
</html>