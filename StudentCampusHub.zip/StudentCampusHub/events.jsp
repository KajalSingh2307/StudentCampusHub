<!DOCTYPE html>
<html>
<head>
<title>Events</title>
<link rel="stylesheet" href="css/style.css">
</head>

<body>

<h2>Upcoming Events</h2>

<ul>
    <li>Tech Fest - 20 June</li>
    <li>Coding Competition - 25 June</li>
    <li>AI Workshop - 30 June</li>
</ul>

</body>
</html>