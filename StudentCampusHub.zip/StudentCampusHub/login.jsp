<!DOCTYPE html>
<html>
<head>
<title>Login</title>
<link rel="stylesheet" href="css/style.css">
</head>

<body>

<h2>Student Login</h2>

<form action="LoginServlet" method="post">

Email:
<input type="email" name="email" required>
<br><br>

Password:
<input type="password" name="password" required>
<br><br>

<input type="submit" value="Login">

</form>

</body>
</html>